export class Company {
  id: number;
  name: string;
}
